<!DOCTYPE html>
<html>
<head>
    <title>Our businesses according to their address</title>
    <link rel="stylesheet" type="text/css" href="style(bsses).css">
</head>
<body>
    
  <div class="banner">
    <div class="content">
        <h1>Our businesses addressed accordingly to their respective districts</h1><br/><br/>
   
        <p><b>In Kigali City</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Advice page.php">1. Gasabo</a><br/>
        <a href="Advice page.php">2. Nyarugenge</a><br/>
        <a href="Advice page.php">3. Kicukiro</a><br/><br/><hr>

        <p><b>In Soutern Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Advice page.php">1. Kamonyi</a><br/>
        <a href="Advice page.php">2. Muhanga</a><br/>
        <a href="Advice page.php">3. Ruhango</a><br/>
        <a href="Advice page.php">4. Nyanza</a><br/>
        <a href="Advice page.php">5. Huye</a><br/><br/><hr>

        <p><b>In Northern Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Advice page.php">1. Musanze</a><br/>
        <a href="Advice page.php">2. Rulindo</a><br/>
        <a href="Advice page.php">3. Gakenke</a><br/>
        <a href="Advice page.php">4. Gicumbi</a><br/>
        <a href="Advice page.php">5. Burera</a><br/><br/><hr>

        <p><b>In Western Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Advice page.php">1. Rusizi</a><br/>
        <a href="Advice page.php">2. Nyamasheke</a><br/>
        <a href="Advice page.php">3. Karongi</a><br/>
        <a href="Advice page.php">4. Ngororero</a><br/>
        <a href="Advice page.php">5. Rubavu</a><br/><br/><hr>

        <p><b>In Eastern Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Advice page.php">1. Rwamagana</a><br/>
        <a href="Advice page.php">2. Kirehe</a><br/>
        <a href="Advice page.php">3. Ngoma</a><br/>
        <a href="Advice page.php">4. Bugesera</a><br/>
        <a href="Advice page.php">5. Nyagatare</a><br/><br/><hr></div>
    
</div>
    
</body>
</html>