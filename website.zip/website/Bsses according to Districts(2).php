<!DOCTYPE html>
<html>
<head>
    <title>Our businesses according to their address</title>
    <link rel="stylesheet" type="text/css" href="style(bsses).css">
</head>
<body>
    
  <div class="banner">
    <div class="content">
      <h1>Our businesses addressed accordingly to their respective districts</h1><br/><br/>
   
      <p><b>In Kigali City</b></p><br/>
      <p><u>Businesses located in:</u></p><br/>
        <a href="Gasabo.php">Gasabo</a><br/>
        <a href="Nyarugenge.php">Nyarugenge</a><br/>
        <a href="Kicukiro.php">Kicukiro</a><br/><br/><hr/><br/>

        <p><b>In Soutern Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Kamonyi.php">Kamonyi</a><br/>
        <a href="Muhanga.php">Muhanga</a><br/>
        <a href="Ruhango.php">Ruhango</a><br/>
        <a href="Nyanza.php">Nyanza</a><br/>
        <a href="Huye.php">Huye</a><br/><br/><hr/><br/>

        <p><b>In Northern Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Musanze.php">Musanze</a><br/>
        <a href="Rulindo.php">Rulindo</a><br/>
        <a href="Gakenke.php">Gakenke</a><br/>
        <a href="Gicumbi.php">Gicumbi</a><br/>
        <a href="Burera.php">Burera</a><br/><br/><hr/><br/>

        <p><b>In Western Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Rusizi.php">Rusizi</a><br/>
        <a href="Nyamasheke.php">Nyamasheke</a><br/>
        <a href="Karongi.php">Karongi</a><br/>
        <a href="Ngororero.php">Ngororero</a><br/>
        <a href="Rubavu.php">Rubavu</a><br/><br/><hr/><br/>

        <p><b>In Eastern Province</b></p><br/>
        <p><u>Businesses located in:</u></p><br/>
        <a href="Rwamagana.php">Rwamagana</a><br/>
        <a href="Kirehe.php">Kirehe</a><br/>
        <a href="Ngoma.php">Ngoma</a><br/>
        <a href="Bugesera.php">Bugesera</a><br/>
        <a href="Nyagatare.php">Nyagatare</a><br/><br/><hr/><br/>
  </div>
    
</div>
    
</body>
</html>