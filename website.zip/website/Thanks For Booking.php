<!DOCTYPE html>
<html>
<head>
    <title>Advice page</title>
    <link rel="stylesheet" type="text/css" href="style(contact).css">
</head>
<body>
    <div class="banner">
        <div class="content">
            <h2>Thank you IVAN MANZI<br/>
                for your time to book items, products or services<br/>
                of our businesses from different locations<br/>
                through AMAZONA WEB online shop.<br/><br/>
                If you also need to pay your items or services<br/>
                in advance, you can click here <a href="Purchase&Ordering.php">Purchase</a> to pay inadvance.<br/><br/><br/>

                

            </h2>
            <p>&copy; 2023 AMAZONA WEB</p>  
        </div>
    </div>
                
       
        
</body>
</html>

