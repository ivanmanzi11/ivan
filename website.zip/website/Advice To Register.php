<!DOCTYPE html>
<html>
<head>
    <title>Advice page</title>
    <link rel="stylesheet" type="text/css" href="style(contact).css">
</head>
<body>
    <div class="banner">
        <div class="content">
            <h2>You don't have an account,<br/>
                to proceed, you need to register<br/>
                your account under<a href="Register.php">Register</a>.<br/>
            </h2>
            
                <p>&copy; 2023 AMAZONA WEB</p>
        </div>
        
    </div>
</body>
</html>

