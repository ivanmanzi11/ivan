<!DOCTYPE html>
<html>
<head>
    <title>Advice page</title>
    <link rel="stylesheet" type="text/css" href="style(contact).css">
</head>
<body>
    <div class="banner">
        <div class="content">
            <h2>Thank you IVAN MANZI<br/>
                for your time to pay for items or services<br/>
                of our businesses from different locations<br/>
                through AMAZONA WEB online shop.<br/><br/>
                You can manage your items or services on your Dashboard<br/>
                click here to access your Dashboard <a href="Dashboard.php">manage products</a> <br>

                

            </h2>
            <br/><br/>
            <p>&copy; 2023 AMAZONA WEB</p>     
        </div>
          
    </div>
</body>
</html>

