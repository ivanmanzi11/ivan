<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style(gasabo).css">
    
</head>
<body>
    <div class="banner">
        <h1>Available Businesses in Gakenke District.</h1>
        <br/><hr/><br/>

        <h2>Gakenke Great Great Drinks</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>Gakenke Hotel</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>BK branch</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>Bralirwa Great Drinks</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>Ubumwe Grand Shop</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>Azam</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>Vision hotel</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>Dufate Kamwe Bar</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>
        
        <h2>Kanyobwa shop</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

        <h2>Mahoro shop</h2><br/>
        <li><a href="Home.php">Home</a></li>
        <li><a href="Purchase&Ordering.php">Products&Price</a></li>
        <li><a href="Contact.php">Address&Contact</a></li><br/><hr/><br/>

    </div>

    
    
        
            
           
    <p>&copy; 2023 AMAZONA WEB</p>            
           
        
    
   
       
          
       
   
   


   
</body>
</html>








